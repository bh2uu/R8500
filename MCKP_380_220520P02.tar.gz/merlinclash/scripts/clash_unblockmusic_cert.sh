#!/bin/sh

source /koolshare/scripts/base.sh
eval `dbus export merlinclash_`

filepath=/koolshare/bin/UnblockMusic
filename=ca.crt

mkdir -p /var/wwwext
ln -sf /var/wwwext /www/ext

cp -rf $filepath/$filename /www/ext/$filename

