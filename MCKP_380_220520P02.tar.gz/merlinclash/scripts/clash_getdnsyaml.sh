#!/bin/sh

export KSROOT=/koolshare
source $KSROOT/scripts/base.sh
eval $(dbus export merlinclash)
alias echo_date='echo 【$(date +%Y年%m月%d日\ %X)】:'
#
rm -rf /tmp/clash_redirhost_view.txt
rm -rf /tmp/clash_fakeip_view.txt
ln -sf /koolshare/merlinclash/yaml_dns/$merlinclash_dnsedit_tag.yaml /tmp/clash_${merlinclash_dnsedit_tag}_view.txt


