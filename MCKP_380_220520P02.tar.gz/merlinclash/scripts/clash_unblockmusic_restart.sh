#!/bin/sh

source /koolshare/scripts/base.sh
eval `dbus export merlinclash_`

if [ "$merlinclash_enable" == "1" ];then
	echo "网易云音乐解锁快速重启" >> /tmp/merlinclash_log.txt
	sh /koolshare/scripts/clash_unblockneteasemusic.sh restart
else
	echo "请先启用merlinclash" >> /tmp/merlinclash_log.txt		
fi
echo BBABBBBC >> /tmp/merlinclash_log.txt


