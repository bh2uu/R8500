#!/bin/sh

export KSROOT=/koolshare
source $KSROOT/scripts/base.sh
eval $(dbus export merlinclash_)
alias echo_date='echo 【$(date +%Y年%m月%d日\ %X)】:'
#
get(){
	a=$(echo $(dbus get $1))
	a=$(echo $(dbus get $1))
	echo $a
}
mcflag=$(get merlinclash_flag)
action=$(get merlinclash_action2)

case $action in
ipsetproxy)
    if [ -f "/koolshare/merlinclash/yaml_basic/ipsetproxy.yaml" ]; then
        ln -sf /koolshare/merlinclash/yaml_basic/ipsetproxy.yaml /tmp/clash_ipsetproxy.txt
    else
        rm -rf /tmp/clash_ipsetproxy.txt
    fi
    if [ -f "/koolshare/merlinclash/yaml_basic/ipsetproxyarround.yaml" ]; then
        ln -sf /koolshare/merlinclash/yaml_basic/ipsetproxyarround.yaml /tmp/clash_ipsetproxyarround.txt
    else   
        rm -rf /tmp/clash_ipsetproxyarround.txt
    fi
    ;;
koolproxy)
    if [ -f "/koolshare/merlinclash/yaml_basic/kpipset.yaml" ]; then
        ln -sf /koolshare/merlinclash/yaml_basic/kpipset.yaml /tmp/clash_kpipset.txt
    else
        rm -rf /tmp/clash_kpipset.txt
    fi
    if [ -f "/koolshare/merlinclash/yaml_basic/kpipsetarround.yaml" ]; then
        ln -sf /koolshare/merlinclash/yaml_basic/kpipsetarround.yaml /tmp/clash_kpipsetarround.txt
    else   
        rm -rf /tmp/clash_kpipsetarround.txt
    fi
    ;;
esac


