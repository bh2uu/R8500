#!/bin/sh

export KSROOT=/koolshare
source $KSROOT/scripts/base.sh
eval $(dbus export merlinclash_)
alias echo_date='echo 【$(date +%Y年%m月%d日\ %X)】:'
LOG_FILE=/tmp/merlinclash_log.txt

#echo_date "download" >> $LOG_FILE
#echo_date "定位文件" >> $LOG_FILE
action=$(dbus get merlinclash_action)
mkdir -p /www/ext

backup_conf(){
	dbus list merlinclash_acl_ |  sed 's/=/=\"/' | sed 's/$/\"/g'|sed 's/^/dbus set /' | sed '1 isource /koolshare/scripts/base.sh' |sed '1 i#!/bin/sh' > /www/ext/clash_rulebackup.htm
	dbus list merlinclash_ipset |  sed 's/=/=\"/' | sed 's/$/\"/g'|sed 's/^/dbus set /' >> > /www/ext/clash_rulebackup.htm #自定义绕行/转发clash内容
}

remove_silent(){
	echo_date 先清除已有的参数... >> $LOG_FILE
	acls=`dbus list merlinclash_acl_ | cut -d "=" -f 1`
	for acl in $acls
	do
		echo_date 移除$acl 
		dbus remove $acl
	done
	ipsets=`dbus list merlinclash_ipset | cut -d "=" -f 1`
	for ipset in $ipsets
	do
		echo_date 移除$ipset 
		dbus remove $ipset
	done
	echo_date "--------------------"
}

restore_sh(){
	echo_date 检测到自定义规则备份文件... >> $LOG_FILE
	echo_date 开始恢复... >> $LOG_FILE
	chmod +x /tmp/clash_rulebackup.sh
	sh /tmp/clash_rulebackup.sh
	echo_date 配置恢复成功！>> $LOG_FILE
}
restore_now(){
	[ -f "/tmp/clash_rulebackup.sh" ] && restore_sh
	echo_date 一点点清理工作... >> $LOG_FILE
	rm -rf /tmp/clash_rulebackup.sh
	echo_date 完成！>> $LOG_FILE
}

case $action in
36)
	backup_conf

	;;
23)
	echo "还原自定义规则" > $LOG_FILE

	remove_silent 
	restore_now 
	echo BBABBBBC >>  $LOG_FILE
	;;
esac